﻿namespace AppDev.Application
{
    public class Class1
    {

    }
}