﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppDev.Application.Common
{
    public interface IDateTime
    {
        DateTime Now { get; }
    }
}
