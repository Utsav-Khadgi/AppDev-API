﻿namespace AppDev.Domain
{
    public class Class1
    {

    }
}