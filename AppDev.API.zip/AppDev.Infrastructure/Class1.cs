﻿namespace AppDev.Infrastructure
{
    public class Class1
    {

    }
}